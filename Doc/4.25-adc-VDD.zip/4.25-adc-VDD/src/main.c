/**
  ******************************************************************************
  * @file    Project/Template/main.c
  * @author  MCD Application Team
  * @version V1.3.0
  * @date    07/14/2010
  * @brief   Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDIN THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 
	
/* Includes ------------------------------------------------------------------*/
#include "stm8l15x.h"
#include "delay.h"
#include "stm8l_discovery_lcd.h"
/** @addtogroup Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Theorically BandGAP 1.224volt */
#define VREF 		1.224L
#define ADC_CONV 	4096
/* Private functions ---------------------------------------------------------*/
void display(uint16_t PotVoltage);
void VREF_Init(void);
u16 VREF_Value(void);//�����ڲ��ο���ѹVREFֵ������8��ƽ��
/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */

void main(void)
{
  uint16_t VADC=0;
  float f_Vdd_appli=0 ;
  CLK_SYSCLKDivConfig(CLK_SYSCLKDiv_1);//ϵͳ1��Ƶ��16M
  LCD_GLASS_Init();//LCD��ʼ��
  VREF_Init();
  /* Infinite loop */
  while (1)
  {
    VADC = VREF_Value();
    /* We use the theorcial value */
    f_Vdd_appli = (VREF/VADC) * ADC_CONV;
	/* Vdd_appli in mV */  
    f_Vdd_appli *= 1000L;
    display((uint16_t)f_Vdd_appli);//LCD��ʾ��ѹֵ
    delay_ms(1000);
  }
}
void display(uint16_t PotVoltage)
{
    uint16_t tab[6];
    tab[0]=PotVoltage/1000+0x30;	
    tab[0] |= DOT; /* To add decimal point for display in volt */
    tab[1]=PotVoltage/100%10+0x30;
    	
    tab[2]=PotVoltage/10%10+0x30;	
    tab[3]=PotVoltage%10+0x30;
    tab[4] = 'V';
    tab[5]=' ';
    LCD_GLASS_DisplayStrDeci(tab);
}
void VREF_Init(void)
{
	/* Enable ADC clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_ADC1, ENABLE);

/* de-initialize ADC */
  ADC_DeInit(ADC1);

/*ADC configuration
  ADC configured as follow:
  - Channel VREF
  - Mode = Single ConversionMode(ContinuousConvMode disabled)
  - Resolution = 12Bit
  - Prescaler = /2
  - sampling time 384 */
  
  ADC_VrefintCmd(ENABLE);
  //delay_10us(3);
  
  
  ADC_Cmd(ADC1, ENABLE);	 
  ADC_Init(ADC1, ADC_ConversionMode_Single,
  ADC_Resolution_12Bit, ADC_Prescaler_2);
  
  ADC_SamplingTimeConfig(ADC1, ADC_Group_SlowChannels, ADC_SamplingTime_384Cycles);
  ADC_ChannelCmd(ADC1, ADC_Channel_Vrefint, ENABLE);
}
u16 VREF_Value(void)//�����ڲ��ο���ѹVREFֵ������8��ƽ��
{
  uint8_t i;
  uint16_t res=0;
  for(i=8; i>0; i--)
  {
/* start ADC convertion by software */
    ADC_SoftwareStartConv(ADC1);
/* wait until end-of-covertion */
    while( ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == 0 );
/* read ADC convertion result */
    res += ADC_GetConversionValue(ADC1);
  }
  return (res>>3);
}
/**
  * @brief  Inserts a delay time.
  * @param  nCount: specifies the delay time length.
  * @retval None
  */

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/